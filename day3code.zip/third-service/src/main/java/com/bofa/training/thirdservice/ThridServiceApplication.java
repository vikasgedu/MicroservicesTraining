package com.bofa.training.thirdservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThridServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThridServiceApplication.class, args);
	}

}
