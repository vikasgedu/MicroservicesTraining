package com.bofa.training.loggingapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoggingApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
