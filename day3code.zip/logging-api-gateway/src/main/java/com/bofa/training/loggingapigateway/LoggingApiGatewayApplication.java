package com.bofa.training.loggingapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoggingApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoggingApiGatewayApplication.class, args);
	}

}
