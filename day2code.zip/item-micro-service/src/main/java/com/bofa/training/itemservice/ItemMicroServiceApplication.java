package com.bofa.training.itemservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItemMicroServiceApplication.class, args);
	}

}
