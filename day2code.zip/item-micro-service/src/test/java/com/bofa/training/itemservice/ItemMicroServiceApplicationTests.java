package com.bofa.training.itemservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
