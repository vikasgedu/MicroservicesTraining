package com.bofa.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestJpaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
