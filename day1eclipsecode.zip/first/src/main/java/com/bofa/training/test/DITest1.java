package com.bofa.training.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.bofa.training.beans.Customer;
import com.bofa.training.config.BeanConfig;

public class DITest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//creates the ioc container and instantiates the beans
		ApplicationContext context=new AnnotationConfigApplicationContext(BeanConfig.class);
		Customer customer=context.getBean(Customer.class);
		System.out.println(customer.getId()+"\t"+customer.getName());

	}

}
