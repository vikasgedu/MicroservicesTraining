package com.bofa.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bofa.training.beans.autowiring.Address;
import com.bofa.training.beans.autowiring.Customer;


@Configuration
public class ThirdConfig {

	@Bean("cust")
	public Customer getCustomer() {
		System.out.println("getCustomer");
		Customer customer=new Customer();
		customer.setId(9001);
		customer.setName("Arjun");
		return customer;
	}
	@Bean
	//The default bean id is getAddress
	public Address getAddress() {
		System.out.println("getAddress");
		return new Address("Hebbal", "Bangalore");
	}
	
}


