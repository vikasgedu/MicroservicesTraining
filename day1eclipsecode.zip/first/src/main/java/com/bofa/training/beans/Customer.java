package com.bofa.training.beans;

import org.springframework.stereotype.Component;

@Component("cust3")
public class Customer {
	private int id=1001;
	private String name="Arvind";
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	

}
