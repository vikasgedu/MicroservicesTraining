package com.bofa.training.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
//looks for the components in com.bofa.training.beans , creates objects of the beans and adds them
//to the ioc container.
@ComponentScan(basePackages = "com.bofa.training.beans")
public class BeanConfig {
	
}
