package com.bofa.training.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bofa.training.beans.Customer;
import com.bofa.training.config.BeanConfig;

public class DITest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//creates the ioc container and instantiates the beans
		ApplicationContext context=new ClassPathXmlApplicationContext("testbeans.xml");
		Customer customer=(Customer) context.getBean("cust1");
		System.out.println(customer.getId()+"\t"+customer.getName());
		customer=(Customer) context.getBean("cust2");
		System.out.println(customer.getId()+"\t"+customer.getName());

	}

}
