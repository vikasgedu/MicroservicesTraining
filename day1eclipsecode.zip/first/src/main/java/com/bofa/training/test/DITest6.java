package com.bofa.training.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.bofa.training.beans.autowiring.Address;
import com.bofa.training.beans.autowiring.Customer;
import com.bofa.training.config.ThirdConfig;

public class DITest6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//creates the ioc container and instantiates the beans
		ApplicationContext context=new AnnotationConfigApplicationContext(ThirdConfig.class);
		System.out.println("IOC container initialized");
		Customer customer=(Customer) context.getBean("cust");
		Address address=customer.getAddress();
		System.out.println(customer.getId()+"\t"+customer.getName());
		System.out.println(address.getLocation()+"\t"+address.getCity());
		
		Address address2=(Address)context.getBean("getAddress");
		System.out.println(address2.getLocation()+"\t"+address2.getCity());

	}

}
