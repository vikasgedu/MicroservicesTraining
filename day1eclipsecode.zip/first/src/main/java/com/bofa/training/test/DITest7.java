package com.bofa.training.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.bofa.training.beans.collections.Address;
import com.bofa.training.beans.collections.Customer;
import com.bofa.training.config.FourthConfig;



public class DITest7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//creates the ioc container and instantiates the beans
		ApplicationContext context=new AnnotationConfigApplicationContext(FourthConfig.class);
		System.out.println("IOC container initialized");
		Customer customer=(Customer) context.getBean("cust");
		
		System.out.println(customer.getId()+"\t"+customer.getName());
		for(Address address:customer.getAddresses()) {
			System.out.println(address.getLocation()+"\t"+address.getCity());
		}
	}

}
