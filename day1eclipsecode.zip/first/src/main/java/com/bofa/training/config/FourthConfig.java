package com.bofa.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bofa.training.beans.collections.Address;
import com.bofa.training.beans.collections.Customer;



@Configuration
public class FourthConfig {

	@Bean("cust")
	public Customer getCustomer() {
		return new Customer(8001,"Rakesh");
	}
	@Bean
	public Address getAddress1() {
		
		return new Address("Hebbal", "Bangalore");
	}
	@Bean
	public Address getAddress2() {
		
		return new Address("Hinjewadi", "Pune");
	}
	@Bean
	public Address getAddress3() {
		
		return new Address("Panjakutta", "Hyderabad");
	}
	
		
}


